import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.functions.{concat, lit, year}
import org.apache.spark.sql.SaveMode

object problem2 extends App {
  System.setProperty("hadoop.home.dir", "C:\\hadoop")
  val spark = SparkSession.builder().appName("problem2").master("local").getOrCreate()
  val sc = spark.sparkContext
  import spark.implicits._
  sc.setLogLevel("ERROR")

  val member_eligibility = spark.read
    .format("com.crealytics.spark.excel")
    .option("header", "true") // Required
    .option("treatEmptyValuesAsNulls", "false") // Optional, default: true
    .option("inferSchema", "true") // Optional, default: false
    .option("addColorColumns", "false") // Optional, default: false
    .load("member_eligibility.xlsx")

  val member_months = spark.read
    .format("com.crealytics.spark.excel")
    .option("header", "true") // Required
    .option("treatEmptyValuesAsNulls", "false") // Optional, default: true
    .option("inferSchema", "true") // Optional, default: false
    .option("addColorColumns", "false") // Optional, default: false
    .load("member_months.xlsx")

  val mem_yr_cnt = member_months.groupBy($"member_id",year('eligiblity_effective_date).alias("member_year")).count()
    .select('member_id,'count.alias("mem_mnth_cnt"),'member_year)
  val mem_mnth_yr = member_months.select('member_id,'eligibility_member_month,year('eligiblity_effective_date).alias("member_year"))
  val mem_year_months_cnt = mem_yr_cnt.join(mem_mnth_yr, Seq("member_id","member_year"),"inner")
    .select('member_id,'mem_mnth_cnt,'eligibility_member_month).distinct()
  mem_year_months_cnt.show()
  mem_year_months_cnt.write.mode(SaveMode.Overwrite).json("output2")

}
