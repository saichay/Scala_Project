import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{concat, lit}

object problem1 extends App {
  System.setProperty("hadoop.home.dir", "C:\\hadoop")
  val spark = SparkSession.builder().appName("problem1").master("local").getOrCreate()
  val sc = spark.sparkContext
  import spark.implicits._
  sc.setLogLevel("ERROR")

  val member_eligibility = spark.read
    .format("com.crealytics.spark.excel")
    .option("header", "true") // Required
    .option("treatEmptyValuesAsNulls", "false") // Optional, default: true
    .option("inferSchema", "true") // Optional, default: false
    .option("addColorColumns", "false") // Optional, default: false
    .load("member_eligibility.xlsx")

  val member_months = spark.read
    .format("com.crealytics.spark.excel")
    .option("header", "true") // Required
    .option("treatEmptyValuesAsNulls", "false") // Optional, default: true
    .option("inferSchema", "true") // Optional, default: false
    .option("addColorColumns", "false") // Optional, default: false
    .load("member_months.xlsx")

  val mem_months_cnt = member_months.groupBy($"member_id").count().select('member_id,'count.alias("mem_mnth_cnt"))
  val out_df = member_eligibility.join(mem_months_cnt,Seq("member_id"),"inner")
                .select('member_id,concat('first_name,lit(' '),'middle_name,lit(' '),'last_name).alias("full_name"),'mem_mnth_cnt)
  out_df.write.partitionBy("member_id").json("output/problem1/")

}
